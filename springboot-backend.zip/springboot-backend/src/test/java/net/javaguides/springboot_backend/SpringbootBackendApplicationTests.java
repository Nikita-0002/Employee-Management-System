package net.javaguides.springboot_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
